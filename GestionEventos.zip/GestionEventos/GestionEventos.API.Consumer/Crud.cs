﻿using System.Net.Http.Json;
using System.Text;

using Newtonsoft.Json;

namespace GestionEventos.API.Consumer
{
    public class Crud<T>
    {
        public static string EndPoint;

        private static HttpClient GetHttpClient()
        {
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
            };
            return new HttpClient(handler);
        }

        public static List<T> GetAll()
        {
            var client = GetHttpClient();
            var response = client.GetAsync(EndPoint).Result;
            var content = response.Content.ReadAsStringAsync().Result;

            if (response.IsSuccessStatusCode)
            {
                return JsonConvert.DeserializeObject<List<T>>(content);
            }
            throw new Exception($"GET Error: {response.StatusCode}, Details: {content}");
        }

        public static T GetById(int id)
        {
            var client = GetHttpClient();
            var response = client.GetAsync($"{EndPoint}/{id}").Result;
            var content = response.Content.ReadAsStringAsync().Result;

            if (response.IsSuccessStatusCode)
            {
                return JsonConvert.DeserializeObject<T>(content);
            }
            throw new Exception($"GET BY ID Error: {response.StatusCode}, Details: {content}");
        }

        public static T Create(T item)
        {
            var client = GetHttpClient();
            var json = JsonConvert.SerializeObject(item);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = client.PostAsync(EndPoint, content).Result;
            var responseBody = response.Content.ReadAsStringAsync().Result;

            if (response.IsSuccessStatusCode)
            {
                return JsonConvert.DeserializeObject<T>(responseBody);
            }
            throw new Exception($"POST Error: {response.StatusCode}, Details: {responseBody}");
        }

        public static bool Update(int id, T item)
        {
            var client = GetHttpClient();
            var json = JsonConvert.SerializeObject(item);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = client.PutAsync($"{EndPoint}/{id}", content).Result;
            var responseBody = response.Content.ReadAsStringAsync().Result;

            if (response.IsSuccessStatusCode)
            {
                return true;
            }
            throw new Exception($"PUT Error: {response.StatusCode}, Details: {responseBody}");
        }

        public static bool Delete(int id)
        {
            var client = GetHttpClient();
            var response = client.DeleteAsync($"{EndPoint}/{id}").Result;
            var content = response.Content.ReadAsStringAsync().Result;

            if (response.IsSuccessStatusCode)
            {
                return true;
            }
            throw new Exception($"DELETE Error: {response.StatusCode}, Details: {content}");
        }
    }
}

