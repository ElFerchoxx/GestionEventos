﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GestionEventos;

namespace GestionEventos.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PonenteSesionesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PonenteSesionesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/PonenteSesiones
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PonenteSesion>>> GetPonenteSesion()
        {
            return await _context.PonenteSesion.ToListAsync();
        }

        // GET: api/PonenteSesiones/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PonenteSesion>> GetPonenteSesion(int id)
        {
            var ponenteSesion = await _context.PonenteSesion.FindAsync(id);

            if (ponenteSesion == null)
            {
                return NotFound();
            }

            return ponenteSesion;
        }

        // PUT: api/PonenteSesiones/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPonenteSesion(int id, PonenteSesion ponenteSesion)
        {
            if (id != ponenteSesion.id)
            {
                return BadRequest();
            }

            _context.Entry(ponenteSesion).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PonenteSesionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/PonenteSesiones
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<PonenteSesion>> PostPonenteSesion(PonenteSesion ponenteSesion)
        {
            _context.PonenteSesion.Add(ponenteSesion);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPonenteSesion", new { id = ponenteSesion.id }, ponenteSesion);
        }

        // DELETE: api/PonenteSesiones/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePonenteSesion(int id)
        {
            var ponenteSesion = await _context.PonenteSesion.FindAsync(id);
            if (ponenteSesion == null)
            {
                return NotFound();
            }

            _context.PonenteSesion.Remove(ponenteSesion);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PonenteSesionExists(int id)
        {
            return _context.PonenteSesion.Any(e => e.id == id);
        }
    }
}
