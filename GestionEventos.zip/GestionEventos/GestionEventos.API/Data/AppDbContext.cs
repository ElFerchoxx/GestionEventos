﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GestionEventos;

public class AppDbContext: DbContext
    {
    public AppDbContext(DbContextOptions<AppDbContext> options) 
        : base(options)
    {
    }
    public DbSet<GestionEventos.Evento> Eventos { get; set; }
    public DbSet<GestionEventos.Inscripcion> Inscripciones { get; set; }
    public DbSet<GestionEventos.Ponente> Ponentes { get; set; }
    public DbSet<GestionEventos.Sesion> Sesiones { get; set; }
    public DbSet<GestionEventos.Certificado> Certificados { get; set; }
    public DbSet<GestionEventos.Historial> Historiales { get; set; }
    public DbSet<GestionEventos.Pago> Pagos { get; set; }

    public DbSet<GestionEventos.Participante> Participante { get; set; } = default!;

    public DbSet<GestionEventos.PonenteSesion> PonenteSesion { get; set; } = default!;
}

