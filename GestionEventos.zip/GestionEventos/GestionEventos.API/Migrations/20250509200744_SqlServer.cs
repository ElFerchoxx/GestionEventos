﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GestionEventos.API.Migrations
{
    /// <inheritdoc />
    public partial class SqlServer : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Eventos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    fecha = table.Column<DateTime>(type: "datetime2", nullable: false),
                    lugar = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    tipo = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Eventos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Ponentes",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    apellidos = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    edad = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ponentes", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Participante",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    apellidos = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    edad = table.Column<int>(type: "int", nullable: false),
                    Eventoid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Participante", x => x.id);
                    table.ForeignKey(
                        name: "FK_Participante_Eventos_Eventoid",
                        column: x => x.Eventoid,
                        principalTable: "Eventos",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Sesiones",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    horaInicio = table.Column<TimeSpan>(type: "time", nullable: false),
                    horaFin = table.Column<TimeSpan>(type: "time", nullable: false),
                    sala = table.Column<int>(type: "int", nullable: false),
                    idEvento = table.Column<int>(type: "int", nullable: false),
                    Eventoid = table.Column<int>(type: "int", nullable: true),
                    Ponenteid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sesiones", x => x.id);
                    table.ForeignKey(
                        name: "FK_Sesiones_Eventos_Eventoid",
                        column: x => x.Eventoid,
                        principalTable: "Eventos",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_Sesiones_Ponentes_Ponenteid",
                        column: x => x.Ponenteid,
                        principalTable: "Ponentes",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Certificados",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    fechaemision = table.Column<DateTime>(type: "datetime2", nullable: false),
                    idparticipante = table.Column<int>(type: "int", nullable: false),
                    Participanteid = table.Column<int>(type: "int", nullable: true),
                    idevento = table.Column<int>(type: "int", nullable: false),
                    Eventoid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Certificados", x => x.id);
                    table.ForeignKey(
                        name: "FK_Certificados_Eventos_Eventoid",
                        column: x => x.Eventoid,
                        principalTable: "Eventos",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_Certificados_Participante_Participanteid",
                        column: x => x.Participanteid,
                        principalTable: "Participante",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Inscripciones",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    estado = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    fechaInscripcion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    idEvento = table.Column<int>(type: "int", nullable: false),
                    Eventoid = table.Column<int>(type: "int", nullable: true),
                    idParticipante = table.Column<int>(type: "int", nullable: false),
                    Participanteid = table.Column<int>(type: "int", nullable: true),
                    Sesionid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Inscripciones", x => x.id);
                    table.ForeignKey(
                        name: "FK_Inscripciones_Eventos_Eventoid",
                        column: x => x.Eventoid,
                        principalTable: "Eventos",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_Inscripciones_Participante_Participanteid",
                        column: x => x.Participanteid,
                        principalTable: "Participante",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_Inscripciones_Sesiones_Sesionid",
                        column: x => x.Sesionid,
                        principalTable: "Sesiones",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "PonenteSesion",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    idPonente = table.Column<int>(type: "int", nullable: false),
                    Ponenteid = table.Column<int>(type: "int", nullable: true),
                    idSesion = table.Column<int>(type: "int", nullable: false),
                    Sesionid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PonenteSesion", x => x.id);
                    table.ForeignKey(
                        name: "FK_PonenteSesion_Ponentes_Ponenteid",
                        column: x => x.Ponenteid,
                        principalTable: "Ponentes",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_PonenteSesion_Sesiones_Sesionid",
                        column: x => x.Sesionid,
                        principalTable: "Sesiones",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Pagos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    medio = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    idInscripcion = table.Column<int>(type: "int", nullable: false),
                    fechaPago = table.Column<DateTime>(type: "datetime2", nullable: false),
                    monto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Inscripcionid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pagos", x => x.id);
                    table.ForeignKey(
                        name: "FK_Pagos_Inscripciones_Inscripcionid",
                        column: x => x.Inscripcionid,
                        principalTable: "Inscripciones",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Historiales",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    fechaconsulta = table.Column<DateTime>(type: "datetime2", nullable: false),
                    idevento = table.Column<int>(type: "int", nullable: true),
                    idparticipante = table.Column<int>(type: "int", nullable: true),
                    idinscripcion = table.Column<int>(type: "int", nullable: true),
                    idcertificado = table.Column<int>(type: "int", nullable: true),
                    Certificadoid = table.Column<int>(type: "int", nullable: true),
                    Inscripcionid = table.Column<int>(type: "int", nullable: true),
                    Pagoid = table.Column<int>(type: "int", nullable: true),
                    Participanteid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Historiales", x => x.id);
                    table.ForeignKey(
                        name: "FK_Historiales_Certificados_Certificadoid",
                        column: x => x.Certificadoid,
                        principalTable: "Certificados",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_Historiales_Inscripciones_Inscripcionid",
                        column: x => x.Inscripcionid,
                        principalTable: "Inscripciones",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_Historiales_Pagos_Pagoid",
                        column: x => x.Pagoid,
                        principalTable: "Pagos",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_Historiales_Participante_Participanteid",
                        column: x => x.Participanteid,
                        principalTable: "Participante",
                        principalColumn: "id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Certificados_Eventoid",
                table: "Certificados",
                column: "Eventoid");

            migrationBuilder.CreateIndex(
                name: "IX_Certificados_Participanteid",
                table: "Certificados",
                column: "Participanteid");

            migrationBuilder.CreateIndex(
                name: "IX_Historiales_Certificadoid",
                table: "Historiales",
                column: "Certificadoid");

            migrationBuilder.CreateIndex(
                name: "IX_Historiales_Inscripcionid",
                table: "Historiales",
                column: "Inscripcionid");

            migrationBuilder.CreateIndex(
                name: "IX_Historiales_Pagoid",
                table: "Historiales",
                column: "Pagoid");

            migrationBuilder.CreateIndex(
                name: "IX_Historiales_Participanteid",
                table: "Historiales",
                column: "Participanteid");

            migrationBuilder.CreateIndex(
                name: "IX_Inscripciones_Eventoid",
                table: "Inscripciones",
                column: "Eventoid");

            migrationBuilder.CreateIndex(
                name: "IX_Inscripciones_Participanteid",
                table: "Inscripciones",
                column: "Participanteid");

            migrationBuilder.CreateIndex(
                name: "IX_Inscripciones_Sesionid",
                table: "Inscripciones",
                column: "Sesionid");

            migrationBuilder.CreateIndex(
                name: "IX_Pagos_Inscripcionid",
                table: "Pagos",
                column: "Inscripcionid");

            migrationBuilder.CreateIndex(
                name: "IX_Participante_Eventoid",
                table: "Participante",
                column: "Eventoid");

            migrationBuilder.CreateIndex(
                name: "IX_PonenteSesion_Ponenteid",
                table: "PonenteSesion",
                column: "Ponenteid");

            migrationBuilder.CreateIndex(
                name: "IX_PonenteSesion_Sesionid",
                table: "PonenteSesion",
                column: "Sesionid");

            migrationBuilder.CreateIndex(
                name: "IX_Sesiones_Eventoid",
                table: "Sesiones",
                column: "Eventoid");

            migrationBuilder.CreateIndex(
                name: "IX_Sesiones_Ponenteid",
                table: "Sesiones",
                column: "Ponenteid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Historiales");

            migrationBuilder.DropTable(
                name: "PonenteSesion");

            migrationBuilder.DropTable(
                name: "Certificados");

            migrationBuilder.DropTable(
                name: "Pagos");

            migrationBuilder.DropTable(
                name: "Inscripciones");

            migrationBuilder.DropTable(
                name: "Participante");

            migrationBuilder.DropTable(
                name: "Sesiones");

            migrationBuilder.DropTable(
                name: "Eventos");

            migrationBuilder.DropTable(
                name: "Ponentes");
        }
    }
}
