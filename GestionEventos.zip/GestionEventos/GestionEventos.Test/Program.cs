﻿using GestionEventos.API.Consumer;
using GestionEventos;
public class Program
{
    public static void Main(string[] args)
    {
        ProbarParticipantes();
        ProbarEvento();
        ProbarSesion();
        ProbarPonente();
         ProbarInscripcion();
        ProbarPago();
        ProbarCertificado();
        PorobarPonenteSesion();
       ProbarHistorial(); 
        Console.ReadLine();
    }

    private static void ProbarParticipantes()
    {
        Crud<Participante>.EndPoint = "https://localhost:7236/api/participantes";
        Console.WriteLine("Participantes");
        Console.WriteLine("");
        var participante = Crud<Participante>.Create(new Participante
        {
            id = 0,
            nombre = "Juan",
            apellidos = "Pérez Ismael",
            edad = 30,
           


        });
        var participante1 = Crud<Participante>.Create(new Participante
        {
            id = 0,
            nombre = "Carlos",
            apellidos = "Pérez Chacla",
            edad = 50,


        });
        var participante2 = Crud<Participante>.Create(new Participante
        {
            id = 0,
            nombre = "Natalt",
            apellidos = "Pérez Soctar",
            edad = 18,


        });
        var participante3 = Crud<Participante>.Create(new Participante
        {
            id = 0,
            nombre = "Pepe",
            apellidos = "Pérez Arevalo",
            edad = 32,


        });

        //Actualizar Lista
        participante.nombre = "Ismal(Actualizado)";
        Crud<Participante>.Update(participante.id, participante);
        //Obtener Participantes
        var pacientesList = Crud<Participante>.GetAll();
        foreach (var p in pacientesList)
        {
            
            Console.WriteLine($"Id: {p.id}, Nombre: {p.nombre}, Apellido: {p.apellidos},Edad: {p.edad} ");
        }

    }
    private static void ProbarEvento()
    {
        Crud<Evento>.EndPoint = "http://localhost:5056/api/eventos";
        Console.WriteLine("Eventos");
        Console.WriteLine("");
        var evento = Crud<Evento>.Create(new Evento
        {
            id = 0,
            nombre = "FICA",
            fecha = DateTime.Now,
            lugar = "Ibarra",
            tipo = "Software"
        });
        var evento1 = Crud<Evento>.Create(new Evento
        {
            id = 0,
            nombre = "BASES DE DATOS",
            fecha = DateTime.Now,
            lugar = "Quito",
            tipo = "Software"
        });
        var evento2 = Crud<Evento>.Create(new Evento
        {
            id = 0,
            nombre = "C#",
            fecha = DateTime.Now,
            lugar = "Tulcán",
            tipo = "Software"
        });
        var evento3 = Crud<Evento>.Create(new Evento
        {
            id = 0,
            nombre = "JAVA SCRIPT",
            fecha = DateTime.Now,
            lugar = "Guayaquil",
            tipo = "Sofwtware"
        });

        //Actualizar Lista
        evento.nombre = "Evento 1(Actualizado)";
        Crud<Evento>.Update(evento.id, evento);
        //Obtener Eventos
        var eventosList = Crud<Evento>.GetAll();
        foreach (var e in eventosList)
        {
            Console.WriteLine($"Id: {e.id}, Nombre: {e.nombre}, Fecha: {e.fecha}, Lugar: {e.lugar}, Tipo: {e.tipo}");
        }

    }
    private static void ProbarSesion()
    {
        Crud<Sesion>.EndPoint = "http://localhost:5056/api/sesiones";
        Console.WriteLine("Sesiones");
        Console.WriteLine("");
        var sesion = Crud<Sesion>.Create(new Sesion
        {
            id = 0,
            nombre = "APIS",
            horaInicio = new TimeSpan(10, 0, 0),
            horaFin = new TimeSpan(11, 0, 0),
            sala = 1,
            idEvento = 1

        });
        var sesion1 = Crud<Sesion>.Create(new Sesion
        {
            id = 0,
            nombre = ".NET",
            horaInicio = new TimeSpan(10, 0, 0),
            horaFin = new TimeSpan(11, 0, 0),
            sala = 1,
            idEvento = 2
        });
        // Segundo Sesion
        var sesion2 = Crud<Sesion>.Create(new Sesion
        {
            id = 0,
            nombre = "SmartConstructor",
            horaInicio = new TimeSpan(11, 30, 0),
            horaFin = new TimeSpan(12, 30, 0),
            sala = 2,
            idEvento = 3
        });
        var sesion3 = Crud<Sesion>.Create(new Sesion
        {
            id = 0,
            nombre = "MachineLearning",
            horaInicio = new TimeSpan(10, 0, 0),
            horaFin = new TimeSpan(13, 0, 0),
            sala = 1,
            idEvento = 4
        });
      
        //Actualizar Lista
        sesion.nombre = "API.Rest(Actualizado)";
        Crud<Sesion>.Update(sesion.id, sesion);
        //Obtener Eventos
        var eventosList = Crud<Sesion>.GetAll();
        foreach (var e in eventosList)
        {
            Console.WriteLine($"Id: {e.id}, Nombre: {e.nombre}, Hora Inicio: {e.horaInicio}, Hora Fin: {e.horaFin}, Sala: {e.sala}");
        }
    }
    private static void ProbarPonente()
    {
        Crud<Ponente>.EndPoint = "http://localhost:5056/api/ponentes";
        Console.WriteLine("Ponentes");
        Console.WriteLine("");
        var ponente = Crud<Ponente>.Create(new Ponente
        {
            id = 0,
            nombre = "Edgardo",
            apellidos = "Joaquin",
            edad = 35,

        });
        var ponente1 = Crud<Ponente>.Create(new Ponente
        {
            id = 0,
            nombre = "Michael",
            apellidos = "Geovany",
            edad = 40,
        });

        // Segundo Ponente
        var ponente2 = Crud<Ponente>.Create(new Ponente
        {
            id = 0,
            nombre = "Erik",
            apellidos = "Saraguro",
            edad = 45,
        });
        var ponente3 = Crud<Ponente>.Create(new Ponente
        {
            id = 0,
            nombre = "Eithan",
            apellidos = "Castro",
            edad = 20,
        });

        //Actualizar Lista
        ponente.nombre = "Ponente 1(Actualizado)";
        Crud<Ponente>.Update(ponente.id, ponente);
        //Obtener Eventos
        var eventosList = Crud<Ponente>.GetAll();
        foreach (var e in eventosList)
        {
            Console.WriteLine($"Id: {e.id}, Nombre: {e.nombre}, Apellido: {e.apellidos}, Edad: {e.edad}");
        }
    }
private static void ProbarInscripcion()
    {
        Crud<Inscripcion>.EndPoint = "http://localhost:5056/api/inscripciones";
        Console.WriteLine("Inscripciones");
        Console.WriteLine("");
        var inscripcion = Crud<Inscripcion>.Create(new Inscripcion
        {
            id = 0,
            estado = "Pendiente",
            fechaInscripcion = DateTime.Now,
            idEvento = 1,
            idParticipante = 1
        });
        var inscripcion1 = Crud<Inscripcion>.Create(new Inscripcion
        {
            id = 0,
            estado = "Cancelado",
            fechaInscripcion = DateTime.Now,
            idEvento = 2,
            idParticipante = 2
        });
        var inscripcion2 = Crud<Inscripcion>.Create(new Inscripcion
        {
            id = 0,
            estado = "Pendiente",
            fechaInscripcion = DateTime.Now,
            idEvento = 2,
            idParticipante = 1
        });
        var inscripcion3 = Crud<Inscripcion>.Create(new Inscripcion
        {
            id = 0,
            estado = "Acreditado",
            fechaInscripcion = new DateTime(2025,05,09,13,0,15),
            idEvento = 2,
            idParticipante = 3
        });
        //Actualizar Lista
        inscripcion.estado = "Completado(Actualizado)";
        Crud<Inscripcion>.Update(inscripcion.id, inscripcion);
        //Obtener Eventos
        var eventosList = Crud<Inscripcion>.GetAll();
        foreach (var e in eventosList)
        {
            Console.WriteLine($"Id: {e.id}, Nombre: {e.estado}, Fecha Inscripcion: {e.fechaInscripcion}, Id Evento: {e.idEvento}, Id Participante: {e.idParticipante}");
        }
    }

private static void ProbarPago()
    {
        Crud<Pago>.EndPoint = "http://localhost:5056/api/pagos";
        Console.WriteLine("Pagos");
        Console.WriteLine("");
        var pago = Crud<Pago>.Create(new Pago
        {
            id = 0,
           idInscripcion = 1,
            medio =" Tarjeta de Debito",
            fechaPago = DateTime.Now,
            monto = "100.00"

        });
        var pago1 = Crud<Pago>.Create(new Pago
        {
            id = 0,
            idInscripcion = 2,
            medio = " De Contado",
            fechaPago = DateTime.Now,
            monto = "120.00"

        });
        var pago2 = Crud<Pago>.Create(new Pago
        {
            id = 0,
            idInscripcion = 3,
            medio = " Cheque",
            fechaPago = DateTime.Now,
            monto = "95.00"

        });
        var pago3 = Crud<Pago>.Create(new Pago
        {
            id = 0,
            idInscripcion = 4,
            medio = " Transferencia",
            fechaPago = DateTime.Now,
            monto = "56.00"

        });

        //Actualizar Lista
        pago.medio = "De Contado (Actualizado)";
        Crud<Pago>.Update(pago.id, pago);
        //Obtener Eventos
        var eventosList = Crud<Pago>.GetAll();
        foreach (var e in eventosList)
        {
            Console.WriteLine($"Id: {e.id}, Medio: {e.medio},  Fecha de Pago: {e.fechaPago}, IdInscripcíon: {e.idInscripcion} Monto: {e.monto} ");
        }
    }
    private static void ProbarCertificado()
    {
        Crud<Certificado>.EndPoint = "http://localhost:5056/api/certificados";
        Console.WriteLine("Certificados");
        Console.WriteLine("");
        var certificado = Crud<Certificado>.Create(new Certificado
        {
            id = 0,
            idparticipante = 1,
            fechaemision = new DateTime(2025,01,01),
         
        });
        var certificado1 = Crud<Certificado>.Create(new Certificado
        {
            id = 0,
            idparticipante = 2,
            fechaemision = new DateTime(2025, 01, 01),

        });
        var certificado2 = Crud<Certificado>.Create(new Certificado
        {
            id = 0,
            idparticipante = 3,
            fechaemision = new DateTime(2025, 01, 01),

        });
        var certificado3 = Crud<Certificado>.Create(new Certificado
        {
            id = 0,
            idparticipante = 4,
            fechaemision = new DateTime(2025, 01, 01),

        });
        //Actualizar Lista
        certificado.fechaemision=new DateTime(2025,02,02);
        Crud<Certificado>.Update(certificado.id, certificado);
        //Obtener Eventos
        var eventosList = Crud<Certificado>.GetAll();
        foreach (var e in eventosList)
        {
            Console.WriteLine($"Id: {e.id}, Fecha Emision: {e.fechaemision}, Id Participante: {e.idparticipante}");
        }
    }
    private static void PorobarPonenteSesion()
    {
        Crud<PonenteSesion>.EndPoint = "http://localhost:5056/api/ponentesesiones";
        Console.WriteLine("Ponentes Sesiones");
        Console.WriteLine("");
        var ponentesion = Crud<PonenteSesion>.Create(new PonenteSesion
        {
            id = 0,
            idPonente = 1,
            idSesion = 1,
            
        });
        var ponentesion1 = Crud<PonenteSesion>.Create(new PonenteSesion
        {
            id = 0,
            idPonente = 2,
            idSesion = 2,

        });
        var ponentesion2 = Crud<PonenteSesion>.Create(new PonenteSesion
        {
            id = 0,
            idPonente = 3,
            idSesion = 3,

        });
        var ponentesion3 = Crud<PonenteSesion>.Create(new PonenteSesion
        {
            id = 0,
            idPonente = 4,
            idSesion = 4,

        });
        //Actualizar Lista
        ponentesion.idPonente = 1;
        Crud<PonenteSesion>.Update(ponentesion.id, ponentesion);
        //Obtener Eventos
        var eventosList = Crud<PonenteSesion>.GetAll();
        foreach (var e in eventosList)
        {
            Console.WriteLine($"Id: {e.id}, Id Ponente: {e.idPonente}, Id Sesion: {e.idSesion}");
        }
    }

    private static void ProbarHistorial()
    {
        Crud<Historial>.EndPoint = "http://localhost:5056/api/historiales";
        Console.WriteLine("Historiales");
        Console.WriteLine("");
        var historial = Crud<Historial>.Create(new Historial
        {
            id = 0,
            idevento = 1,
            idparticipante = 1,
            idinscripcion = 1,
            idcertificado = 1
        });
        var historial1 = Crud<Historial>.Create(new Historial
        {
            id = 0,
            idevento = 2,
            idparticipante = 2,
            idinscripcion = 2,
            idcertificado = 2
        });
        var historial2 = Crud<Historial>.Create(new Historial
        {
            id = 0,
            idevento = 3,
            idparticipante = 3,
            idinscripcion = 3,
            idcertificado = 3
        });
        var historial3 = Crud<Historial>.Create(new Historial
        {
            id = 0,
            idevento = 4,
            idparticipante = 4,
            idinscripcion = 4,
            idcertificado = 4
        });

        //Actualizar Lista
        historial.idevento = 1;
        Crud<Historial>.Update(historial.id, historial);

        //Obtener Historiales
        var eventosList = Crud<Historial>.GetAll();

        // Mostrar todos los registros
        foreach (var e in eventosList)
        {
            Console.WriteLine($"Id: {e.id}, Fecha Consulta: {e.fechaconsulta}, Id Evento: {e.idevento}, Id Participante: {e.idparticipante}, Id Inscripcion: {e.idinscripcion}, Id Certificado: {e.idcertificado}");
        }

        // Mostrar totales agregados
        Console.WriteLine("\n--- Resumen ---");
        var totalEventos = eventosList.Select(h => h.idevento).Where(id => id.HasValue).Distinct().Count();
        var totalParticipantes = eventosList.Select(h => h.idparticipante).Where(id => id.HasValue).Distinct().Count();
        var totalInscripciones = eventosList.Select(h => h.idinscripcion).Where(id => id.HasValue).Distinct().Count();
        var totalCertificados = eventosList.Select(h => h.idcertificado).Where(id => id.HasValue).Distinct().Count();

        Console.WriteLine($"Total eventos únicos: {totalEventos}");
        Console.WriteLine($"Total participantes únicos: {totalParticipantes}");
        Console.WriteLine($"Total inscripciones únicas: {totalInscripciones}");
        Console.WriteLine($"Total certificados únicos: {totalCertificados}");
    }










}