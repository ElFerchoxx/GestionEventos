﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionEventos
{
    public class Certificado
    {
        [Key]public int id { get; set; }
        public DateTime fechaemision { get; set; }
        
        public int idparticipante { get; set; }
        public Participante? Participante { get; set; }
        public int idevento { get; set; }
        public Evento? Evento { get; set; }
        public List<Historial>? historiales { get; set; }
    }

}
