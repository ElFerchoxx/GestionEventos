﻿using System.ComponentModel.DataAnnotations;

namespace GestionEventos
{
    public class Evento
    {
        [Key]public int id { get; set; }
        public string nombre { get; set; }
        public DateTime fecha { get; set; }
        public string lugar { get; set; }
        public string tipo { get; set; }

        public List<Sesion>? sesiones { get; set; }
        public List<Inscripcion>? inscripciones { get; set; }
        public List<Certificado>? certificados { get; set; }
        public List<Participante>? participantes { get; set; }

    }
}
