﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionEventos
{
    public class Historial
    {
        [Key] public int id { get; set; }
        public DateTime fechaconsulta { get; set; }
        public int? idevento { get; set; }
        public int? idparticipante { get; set; }
        public int? idinscripcion { get; set; }
        public int? idcertificado { get; set; }
        
    }
}
