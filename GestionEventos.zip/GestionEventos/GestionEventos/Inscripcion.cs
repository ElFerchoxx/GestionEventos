﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionEventos
{
    public class Inscripcion
    {
        [Key]public int id { get; set; }
        public string estado { get; set; }
        public DateTime fechaInscripcion { get; set; }
        public int idEvento { get; set; }
        public Evento? Evento { get; set; }
        public int idParticipante { get; set; }
        public Participante? Participante { get; set; }
        public List<Historial>? historiales { get; set; }

    }
}
