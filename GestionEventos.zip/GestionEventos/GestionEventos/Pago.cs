﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionEventos
{
    public class Pago
    {
        [Key]public int id { get; set; }
        public string medio { get; set; }
        public int idInscripcion { get; set; }
        public DateTime fechaPago { get; set; }
        public string monto { get; set; }
        public Inscripcion? Inscripcion { get; set; }
        public List<Historial>historiales { get; set; }=new List<Historial>();
    }
}
