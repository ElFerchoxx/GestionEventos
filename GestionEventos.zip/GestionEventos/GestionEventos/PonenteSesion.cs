﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionEventos
{
    public class PonenteSesion
    {
        [Key] public int id { get; set; }
        public int idPonente { get; set; }
        public Ponente? Ponente { get; set; }
        public int idSesion { get; set; }
        public Sesion? Sesion { get; set; }

    }
}
