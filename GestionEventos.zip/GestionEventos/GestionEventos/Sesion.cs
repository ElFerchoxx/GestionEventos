﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionEventos
{
   public  class Sesion
    {
        [Key] public int id { get; set; }
        public string nombre { get; set; }
        public TimeSpan horaInicio { get; set; }
        public TimeSpan horaFin { get; set; }
        public int sala { get; set; }
        public int idEvento { get; set; }
        public Evento? Evento { get; set; }


        public List<Inscripcion>? inscripciones { get; set; }
        public List <PonenteSesion>? ponentesSesiones { get; set; }

    }
}
